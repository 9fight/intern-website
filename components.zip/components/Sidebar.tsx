"use client";

import React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
    LayoutDashboard,
    FileText,
    Image as ImageIcon,
    LogOut,
    ChevronLeft,
    Settings,
    Clock,
    Sparkles
} from "lucide-react";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabase";

const menuItems = [
    { name: "Dashboard", href: "/admin", icon: LayoutDashboard },
    { name: "จัดการรายงาน", href: "/admin/reports", icon: FileText },
    { name: "จัดการแกลเลอรี", href: "/admin/gallery", icon: ImageIcon },
    { name: "จัดการเวลา", href: "/admin/timesheet", icon: Clock },
];

export default function Sidebar() {
    const pathname = usePathname();
    const router = useRouter();

    const handleLogout = async () => {
        const { error } = await supabase.auth.signOut();
        if (!error) router.push("/login");
    };

    return (
        <aside className="fixed left-0 top-0 h-screen w-72 bg-white/80 dark:bg-[#09090b]/80 backdrop-blur-xl border-r border-gray-100 dark:border-white/5 z-50 flex flex-col transition-all duration-300">

            {/* --- Brand Logo Section --- */}
            <div className="p-8">
                <Link href="/" className="flex items-center gap-3.5 group">
                    <div className="relative">
                        <div className="w-11 h-11 bg-black dark:bg-white rounded-[1.2rem] flex items-center justify-center group-hover:scale-110 group-hover:rotate-[-6deg] transition-all duration-500 shadow-xl shadow-black/10 dark:shadow-white/5">
                            <ChevronLeft size={22} className="text-white dark:text-black" />
                        </div>
                        <div className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 rounded-full border-2 border-white dark:border-[#09090b] flex items-center justify-center">
                            <Sparkles size={8} className="text-white" />
                        </div>
                    </div>
                    <div className="flex flex-col">
                        <span className="font-black text-xl tracking-tight leading-none text-gray-900 dark:text-white">
                            Admin<span className="text-blue-500">.</span>
                        </span>
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em] mt-1">Portfolio</span>
                    </div>
                </Link>
            </div>

            {/* --- Navigation Links --- */}
            <nav className="flex-1 px-4 py-2 space-y-1">
                <div className="px-5 mb-6">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest opacity-70">Main Menu</p>
                </div>

                {menuItems.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                        <Link key={item.name} href={item.href} className="block relative group">
                            <div className={`
                                flex items-center gap-3.5 px-5 py-3.5 rounded-2xl text-[14px] font-semibold transition-all duration-300 relative z-10
                                ${isActive
                                    ? "text-black dark:text-white"
                                    : "text-gray-500 hover:text-gray-900 dark:hover:text-gray-200"
                                }
                            `}>
                                <item.icon size={20} strokeWidth={isActive ? 2.5 : 2} className={isActive ? "text-blue-500" : "group-hover:text-blue-400 transition-colors"} />
                                {item.name}

                                {isActive && (
                                    <motion.div
                                        layoutId="activeNav"
                                        className="absolute inset-0 bg-gray-100/80 dark:bg-white/5 rounded-2xl -z-10 border border-gray-200/50 dark:border-white/5"
                                        transition={{ type: "spring", stiffness: 350, damping: 30 }}
                                    />
                                )}
                            </div>
                        </Link>
                    );
                })}
            </nav>

            {/* --- Bottom Section (User Card) --- */}
            <div className="p-6 mt-auto">
                <div className="bg-gray-50 dark:bg-white/[0.03] rounded-[2rem] p-4 border border-gray-100 dark:border-white/5 shadow-sm">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 p-[2px]">
                            <div className="w-full h-full rounded-[0.9rem] bg-white dark:bg-black flex items-center justify-center overflow-hidden">
                                <img
                                    src="https://api.dicebear.com/7.x/avataaars/svg?seed=Chet"
                                    alt="User Avatar"
                                    className="w-full h-full object-cover"
                                />
                            </div>
                        </div>
                        <div className="flex flex-col min-w-0">
                            <p className="text-sm font-black truncate text-gray-900 dark:text-white">Chet S.</p>
                            <p className="text-[11px] font-medium text-gray-500 truncate">Developer</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                        <button className="flex items-center justify-center p-2 rounded-xl bg-white dark:bg-white/5 text-gray-500 hover:text-blue-500 hover:shadow-sm transition-all border border-gray-100 dark:border-white/5">
                            <Settings size={16} />
                        </button>
                        <button
                            onClick={handleLogout}
                            className="flex items-center justify-center p-2 rounded-xl bg-red-50 dark:bg-red-500/10 text-red-500 hover:bg-red-100 dark:hover:bg-red-500/20 transition-all border border-red-100 dark:border-red-500/10"
                        >
                            <LogOut size={16} />
                        </button>
                    </div>
                </div>
            </div>
        </aside>
    );
}