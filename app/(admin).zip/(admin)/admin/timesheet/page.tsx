"use client";

import React, { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { motion } from "framer-motion";
import { Clock, UploadCloud, Loader2, Image as ImageIcon, AlertCircle } from "lucide-react";

export default function AdminTimesheet() {
    const [timesheets, setTimesheets] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        fetchTimesheets();
    }, []);

    const fetchTimesheets = async () => {
        setIsLoading(true);
        const { data } = await supabase
            .from('weekly_reports')
            .select('week_num, date_range, timesheet_image')
            .order('week_num', { ascending: true });
        if (data) setTimesheets(data);
        setIsLoading(false);
    };

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 10 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } }
    };

    return (
        <div className="w-full relative min-h-screen">
            <div className="absolute top-20 left-1/4 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-[100px] -z-10 pointer-events-none" />

            <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 px-2">
                <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
                    <h1 className="text-3xl md:text-4xl font-black bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-500 dark:from-white dark:to-gray-500 tracking-tight mb-2">
                        ใบลงเวลา
                    </h1>
                    <p className="text-gray-500 text-sm font-bold">อัปโหลดและตรวจสอบหลักฐานการลงเวลา</p>
                </motion.div>
            </div>

            {isLoading ? (
                <div className="flex justify-center items-center py-32"><Loader2 className="animate-spin text-gray-300" size={32} /></div>
            ) : (
                <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6 px-2">
                    {timesheets.map((ts) => (
                        <motion.div key={ts.week_num} variants={itemVariants} className="bg-white dark:bg-[#111113] rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-white/5 overflow-hidden flex flex-col group">

                            {/* Card Header */}
                            <div className="p-6 md:p-8 pb-4 flex justify-between items-start">
                                <div>
                                    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gray-50 dark:bg-white/5 text-[10px] font-black uppercase tracking-widest mb-2 text-gray-500">
                                        Week {ts.week_num}
                                    </div>
                                    <p className="font-bold text-gray-900 dark:text-white text-base">{ts.date_range}</p>
                                </div>
                                <div className={`p-3 rounded-2xl transition-colors ${ts.timesheet_image ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500' : 'bg-gray-50 dark:bg-white/5 text-gray-400'}`}>
                                    {ts.timesheet_image ? <ImageIcon size={20} strokeWidth={2.5} /> : <AlertCircle size={20} strokeWidth={2.5} />}
                                </div>
                            </div>

                            {/* Dropzone / Image Viewer */}
                            <div className="p-6 md:p-8 pt-0 flex-1">
                                {ts.timesheet_image ? (
                                    <div className="relative w-full aspect-[4/3] rounded-[1.5rem] overflow-hidden border border-gray-100 dark:border-white/10 group-hover:shadow-md transition-all">
                                        <img src={ts.timesheet_image} alt={`Timesheet Week ${ts.week_num}`} className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105" />

                                        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm opacity-0 md:group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center">
                                            <button className="bg-white text-black px-5 py-3 rounded-2xl text-sm font-bold shadow-lg flex items-center gap-2 hover:scale-105 transition-transform">
                                                <UploadCloud size={18} strokeWidth={2.5} /> เปลี่ยนรูป
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    <label className="w-full aspect-[4/3] border-2 border-dashed border-gray-200 dark:border-gray-800 rounded-[1.5rem] flex flex-col items-center justify-center text-gray-400 hover:text-emerald-500 hover:border-emerald-500 hover:bg-emerald-50/50 dark:hover:bg-emerald-500/5 transition-all cursor-pointer relative overflow-hidden">
                                        <div className="w-14 h-14 bg-gray-50 dark:bg-white/5 rounded-2xl flex items-center justify-center mb-4 transition-transform duration-300 group-hover:-translate-y-2 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-500/20 group-hover:text-emerald-500">
                                            <UploadCloud size={24} strokeWidth={2.5} />
                                        </div>
                                        <span className="text-sm font-bold text-gray-700 dark:text-gray-300">คลิกเพื่ออัปโหลด</span>
                                        <span className="text-[11px] font-bold mt-1 text-gray-400 uppercase tracking-widest">JPG, PNG (Max 5MB)</span>
                                        <input type="file" className="hidden" accept="image/*" />
                                    </label>
                                )}
                            </div>
                        </motion.div>
                    ))}
                </motion.div>
            )}
        </div>
    );
}