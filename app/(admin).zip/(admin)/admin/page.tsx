"use client";

import React, { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import {
    Plus, Clock, TrendingUp, Sparkles, Image as ImageIcon, Zap, ChevronRight, Loader2, Target, BarChart3
} from "lucide-react";
import { motion } from "framer-motion";

export default function AdminDashboard() {
    const router = useRouter();
    const [weeks, setWeeks] = useState<any[]>([]);
    const [stats, setStats] = useState({ totalWeeks: 0, totalTasks: 0 });
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const checkUser = async () => {
            const { data: { session } } = await supabase.auth.getSession();
            if (!session) router.push("/login");
            else fetchDashboardData();
        };
        checkUser();
    }, [router]);

    const fetchDashboardData = async () => {
        setIsLoading(true);
        const { data: weeksData } = await supabase
            .from('weekly_reports')
            .select('*, daily_tasks(count)')
            .order('week_num', { ascending: false });

        if (weeksData) {
            setWeeks(weeksData);
            setStats({ totalWeeks: weeksData.length, totalTasks: 0 });
        }
        setIsLoading(false);
    };

    if (isLoading) {
        return <div className="min-h-[80vh] flex justify-center items-center"><Loader2 className="animate-spin text-gray-300" size={32} /></div>;
    }

    // Animation แบบเบาๆ เร็วๆ สมูทๆ (Micro-interaction)
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.05 } } // โหลดเร็วขึ้น
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 10 }, // ระยะกระโดดน้อยลง
        visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } }
    };

    return (
        <div className="w-full relative min-h-screen">
            {/* Background Blob แบบจางมากๆ ไม่แย่งซีน */}
            <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-blue-400/5 rounded-full blur-[120px] -z-10 pointer-events-none" />

            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 px-2">
                <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
                    <h1 className="text-3xl md:text-4xl font-black bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-500 dark:from-white dark:to-gray-500 tracking-tight mb-1">
                        Dashboard
                    </h1>
                    <p className="text-gray-500 text-sm font-bold">
                        ภาพรวมการจัดการรายงานประจำสัปดาห์
                    </p>
                </motion.div>

                <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => router.push('/admin/reports')}
                    className="bg-black dark:bg-white text-white dark:text-black px-5 py-3 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors shadow-sm group"
                >
                    <Plus size={18} strokeWidth={2.5} className="transition-transform group-hover:rotate-90 duration-300" /> เพิ่มรายงานใหม่
                </motion.button>
            </div>

            {/* Bento Grid layout */}
            <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 px-2"
            >
                {/* 1. Latest Status */}
                <motion.div variants={itemVariants} className="lg:col-span-2 rounded-[2rem] bg-gray-900 dark:bg-white p-8 text-white dark:text-black relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 dark:bg-black/5 blur-3xl rounded-full -translate-y-1/2 translate-x-1/3 transition-transform duration-700 group-hover:scale-110 pointer-events-none" />
                    <div className="relative z-10 flex flex-col justify-between h-full min-h-[160px]">
                        <div>
                            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 dark:bg-black/5 border border-white/10 dark:border-black/5 text-[10px] font-bold uppercase tracking-widest mb-4">
                                <Sparkles size={12} className="text-[#00d1b2]" /> System Active
                            </div>
                            <h2 className="text-2xl font-black tracking-tight mb-1">รายงานสัปดาห์ที่ {weeks[0]?.week_num || '-'}</h2>
                            <p className="text-white/60 dark:text-black/60 text-sm font-medium">
                                {weeks[0]?.status || 'ยังไม่มีการอัปเดตสถานะ'}
                            </p>
                        </div>
                        <div className="flex items-end justify-between mt-6">
                            <div>
                                <p className="text-white/40 dark:text-black/40 text-[10px] font-bold uppercase tracking-widest mb-1">ช่วงวันที่</p>
                                <p className="text-sm font-bold">{weeks[0]?.date_range || '-'}</p>
                            </div>
                            <button onClick={() => router.push(`/admin/reports/${weeks[0]?.id}`)} className="p-2.5 rounded-xl bg-white/10 dark:bg-black/5 hover:bg-white/20 transition-colors">
                                <ChevronRight size={18} />
                            </button>
                        </div>
                    </div>
                </motion.div>

                {/* 2. Total Weeks Target */}
                <motion.div variants={itemVariants} className="rounded-[2rem] bg-white dark:bg-[#111113] border border-gray-100 dark:border-white/5 p-6 shadow-sm flex flex-col justify-center items-center text-center group">
                    <div className="w-14 h-14 rounded-[1rem] bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center text-blue-500 mb-4 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-3">
                        <Target size={24} strokeWidth={2.5} />
                    </div>
                    <h3 className="text-4xl font-black text-gray-900 dark:text-white tracking-tighter mb-1">{stats.totalWeeks} <span className="text-lg text-gray-300">/ 8</span></h3>
                    <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-4">สัปดาห์ที่บันทึก</p>
                    <div className="w-full bg-gray-100 dark:bg-white/5 rounded-full h-1.5 overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${(stats.totalWeeks / 8) * 100}%` }} transition={{ duration: 1, ease: "easeOut" }} className="bg-blue-500 h-full rounded-full" />
                    </div>
                </motion.div>

                {/* 3. Performance */}
                <motion.div variants={itemVariants} className="rounded-[2rem] bg-white dark:bg-[#111113] border border-gray-100 dark:border-white/5 p-6 shadow-sm flex flex-col justify-center items-center text-center group">
                    <div className="w-14 h-14 rounded-[1rem] bg-pink-50 dark:bg-pink-500/10 flex items-center justify-center text-pink-500 mb-4 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
                        <TrendingUp size={24} strokeWidth={2.5} />
                    </div>
                    <h3 className="text-4xl font-black text-gray-900 dark:text-white tracking-tighter mb-1">98%</h3>
                    <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-4">ประสิทธิภาพ</p>
                    <div className="flex items-center gap-1.5 text-emerald-500 text-xs font-bold bg-emerald-50 dark:bg-emerald-500/10 px-2.5 py-1 rounded-lg">
                        <Zap size={12} /> +12%
                    </div>
                </motion.div>

                {/* 4. Recent Feed */}
                <motion.div variants={itemVariants} className="lg:col-span-2 lg:row-span-2 rounded-[2rem] bg-white dark:bg-[#111113] border border-gray-100 dark:border-white/5 p-6 md:p-8 shadow-sm">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-lg font-black text-gray-900 dark:text-white flex items-center gap-2">
                            <Clock className="text-gray-400" size={20} strokeWidth={2.5} /> ล่าสุด
                        </h2>
                        <button onClick={() => router.push('/admin/reports')} className="text-xs font-bold text-blue-500 hover:text-blue-600 transition-colors">
                            ดูทั้งหมด
                        </button>
                    </div>
                    <div className="space-y-3">
                        {weeks.slice(0, 4).map((week) => (
                            <div key={week.id} className="p-3.5 rounded-[1.5rem] bg-gray-50/50 dark:bg-white/[0.02] border border-gray-100/50 dark:border-white/5 hover:bg-gray-100 dark:hover:bg-white/5 transition-colors group cursor-pointer flex items-center justify-between gap-4">
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 rounded-xl bg-white dark:bg-black flex items-center justify-center text-gray-900 dark:text-white font-black text-lg border border-gray-100 dark:border-white/5 shadow-sm group-hover:scale-105 transition-transform">
                                        {week.week_num}
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-gray-900 dark:text-white text-sm">{week.date_range}</h3>
                                        <p className="text-xs font-medium text-gray-400 mt-0.5">{week.status || 'รอระบุสถานะ'}</p>
                                    </div>
                                </div>
                                <ChevronRight size={16} className="text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white group-hover:translate-x-1 transition-all mr-2" />
                            </div>
                        ))}
                    </div>
                </motion.div>

                {/* 5. Gallery Access */}
                <motion.div variants={itemVariants} onClick={() => router.push('/admin/gallery')} className="rounded-[2rem] bg-[#00d1b2] p-6 md:p-8 text-white relative overflow-hidden flex flex-col justify-between group cursor-pointer shadow-sm hover:shadow-md transition-shadow">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/20 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2 pointer-events-none transition-transform duration-700 group-hover:scale-150" />
                    <div>
                        <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110">
                            <ImageIcon size={20} strokeWidth={2.5} className="text-white" />
                        </div>
                        <h3 className="text-2xl font-black mb-2 tracking-tight">แกลเลอรี</h3>
                        <p className="text-white/80 text-xs font-medium leading-relaxed">
                            จัดการรูปภาพกิจกรรมและการทำงานในแต่ละสัปดาห์
                        </p>
                    </div>
                    <div className="mt-6 flex items-center text-sm font-bold gap-1 group-hover:gap-2 transition-all">
                        เปิดดู <ChevronRight size={16} />
                    </div>
                </motion.div>

                {/* 6. Simple Tip */}
                <motion.div variants={itemVariants} className="rounded-[2rem] bg-white dark:bg-[#111113] border border-gray-100 dark:border-white/5 p-6 shadow-sm flex flex-col justify-center gap-4 group">
                    <div className="w-10 h-10 bg-orange-50 dark:bg-orange-500/10 rounded-xl flex items-center justify-center text-orange-500 shrink-0 transition-transform duration-300 group-hover:rotate-12">
                        <Zap size={20} strokeWidth={2.5} />
                    </div>
                    <p className="text-sm font-bold text-gray-700 dark:text-gray-300">อย่าลืมอัปเดต Timesheet ให้ตรงกับรายงานเสมอนะครับ</p>
                    <button onClick={() => router.push('/admin/timesheet')} className="text-xs font-bold text-gray-400 hover:text-gray-900 dark:hover:text-white flex items-center gap-1 w-fit transition-colors">
                        เช็ค Timesheet <ChevronRight size={14} />
                    </button>
                </motion.div>

            </motion.div>
        </div>
    );
}