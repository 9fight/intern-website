"use client";

import React, { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { motion, AnimatePresence } from "framer-motion";
import {
    Images, Trash2, Loader2, Calendar,
    X, FolderHeart
} from "lucide-react";

export default function AdminGallery() {
    // กำหนดโครงสร้างเริ่มต้นให้มี 8 สัปดาห์เสมอ ตามที่คุณต้องการ (2 แถว แถวละ 4)
    const [groupedImages, setGroupedImages] = useState<Record<string, any[]>>({
        1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [], 8: []
    });
    const [isLoading, setIsLoading] = useState(true);

    // State สำหรับ Modal (ลบ State Pagination ออกตามที่สั่ง)
    const [selectedWeek, setSelectedWeek] = useState<string | null>(null);

    useEffect(() => {
        fetchGallery();
    }, []);

    const fetchGallery = async () => {
        setIsLoading(true);
        const { data } = await supabase
            .from('daily_tasks')
            .select('id, day_id, image_url, date_str, task_main, week_num, is_holiday')
            .order('week_num', { ascending: true })
            .order('day_id', { ascending: true });

        if (data) {
            const grouped: Record<string, any[]> = {
                1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [], 8: []
            };

            data.forEach((curr: any) => {
                if (grouped[curr.week_num]) {
                    grouped[curr.week_num].push(curr);
                }
            });
            setGroupedImages(grouped);
        }
        setIsLoading(false);
    };

    // --- Framer Motion Variants (คงเดิมตาม UI คุณ) ---
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
    };

    const cardVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } }
    };

    return (
        <div className="w-full relative min-h-screen pb-20">
            {/* Background Blob */}
            <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-[#00d1b2]/5 rounded-full blur-[120px] -z-10 pointer-events-none" />

            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 md:mb-12 gap-4 px-2">
                <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
                    <h1 className="text-3xl md:text-4xl font-black bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-500 dark:from-white dark:to-gray-500 tracking-tight mb-2">
                        แกลเลอรีผลงาน
                    </h1>
                    <p className="text-gray-500 text-sm font-bold">
                        จัดเก็บและแยกรูปภาพตามอัลบั้มรายสัปดาห์
                    </p>
                </motion.div>
            </div>

            {isLoading ? (
                <div className="flex justify-center items-center py-32">
                    <Loader2 className="animate-spin text-gray-300" size={32} />
                </div>
            ) : (
                <>
                    {/* --- Album Grid (คง Icon FolderHeart ไว้ตามเดิม) --- */}
                    <motion.div
                        variants={containerVariants}
                        initial="hidden"
                        animate="visible"
                        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 px-2"
                    >
                        {Object.keys(groupedImages).map((weekNum) => {
                            const items = groupedImages[weekNum];

                            return (
                                <motion.div
                                    key={weekNum}
                                    variants={cardVariants}
                                    onClick={() => setSelectedWeek(weekNum)}
                                    className="bg-white/80 dark:bg-[#111113]/80 backdrop-blur-xl border border-gray-100 dark:border-white/5 rounded-[2.5rem] p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer group flex flex-col items-center text-center relative overflow-hidden"
                                >
                                    <div className="absolute top-10 w-24 h-24 bg-[#00d1b2]/20 rounded-full blur-2xl group-hover:bg-[#00d1b2]/30 transition-colors" />

                                    {/* ส่วนนี้ใช้ Icon FolderHeart ตาม UI ต้นฉบับของคุณครับ */}
                                    <div className="relative w-24 h-24 mb-5 rounded-[1.5rem] bg-[#00d1b2]/10 dark:bg-[#00d1b2]/10 flex items-center justify-center text-[#00d1b2] shadow-inner group-hover:scale-110 transition-transform duration-500">
                                        <FolderHeart size={40} strokeWidth={2} />
                                        <div className="absolute -bottom-2 -right-2 bg-black dark:bg-white text-white dark:text-black text-[10px] font-black px-2.5 py-1 rounded-xl shadow-md border-2 border-white dark:border-[#111113]">
                                            {items.length}
                                        </div>
                                    </div>

                                    <h2 className="text-xl font-black text-gray-900 dark:text-white mb-1">สัปดาห์ที่ {weekNum}</h2>
                                    <p className="text-xs font-bold text-gray-400">อัลบั้มรูปภาพประจำสัปดาห์</p>
                                </motion.div>
                            );
                        })}
                    </motion.div>

                    {/* --- Modal Pop-up (ปรับให้แสดงรูปทั้งหมดในหน้าเดียว ไม่มีการแบ่งหน้า) --- */}
                    <AnimatePresence>
                        {selectedWeek && (
                            <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 md:px-10 py-10">
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    onClick={() => setSelectedWeek(null)}
                                    className="absolute inset-0 bg-black/60 backdrop-blur-md cursor-pointer"
                                />

                                <motion.div
                                    initial={{ opacity: 0, scale: 0.95, y: 20 }}
                                    animate={{ opacity: 1, scale: 1, y: 0 }}
                                    exit={{ opacity: 0, scale: 0.95, y: 20 }}
                                    transition={{ type: "spring", damping: 25, stiffness: 300 }}
                                    className="relative w-full max-w-6xl bg-[#f8fafc] dark:bg-[#09090b] rounded-[3rem] shadow-2xl border border-white/20 dark:border-white/10 overflow-hidden flex flex-col max-h-[90vh]"
                                    onClick={(e) => e.stopPropagation()}
                                >
                                    {/* Modal Header */}
                                    <div className="flex items-center justify-between p-6 md:p-8 bg-white/50 dark:bg-white/5 backdrop-blur-xl border-b border-gray-200/50 dark:border-white/5 shrink-0">
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 rounded-[1.25rem] bg-[#00d1b2]/10 text-[#00d1b2] flex items-center justify-center">
                                                <Images size={24} strokeWidth={2.5} />
                                            </div>
                                            <div>
                                                <h2 className="text-2xl font-black text-gray-900 dark:text-white">อัลบั้มสัปดาห์ที่ {selectedWeek}</h2>
                                                <p className="text-xs font-bold text-gray-500 mt-0.5">ภาพกิจกรรมทั้งหมด {groupedImages[selectedWeek]?.length} รายการ</p>
                                            </div>
                                        </div>
                                        <button
                                            onClick={() => setSelectedWeek(null)}
                                            className="p-3 bg-gray-100 hover:bg-gray-200 dark:bg-white/10 dark:hover:bg-white/20 text-gray-600 dark:text-gray-300 rounded-2xl transition-colors"
                                        >
                                            <X size={20} strokeWidth={2.5} />
                                        </button>
                                    </div>

                                    {/* Modal Body: แสดงรูปภาพทั้งหมด Scroll ดูได้เลย (ลบ Logic การ Slice ข้อมูลทิ้ง) */}
                                    <div className="p-6 md:p-8 overflow-y-auto flex-1 bg-gray-50/50 dark:bg-transparent custom-scrollbar">
                                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-5 pb-6">
                                            {groupedImages[selectedWeek].map((item) => (
                                                <div key={item.id} className="group relative aspect-[4/3] rounded-[2rem] overflow-hidden bg-gray-100 dark:bg-[#1a1a1c] border border-gray-200 dark:border-white/5 shadow-sm">
                                                    <img
                                                        src={item.image_url || 'fallback.jpg'}
                                                        alt={item.task_main}
                                                        className={`w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 ${item.is_holiday ? 'opacity-80' : ''}`}
                                                        loading="lazy"
                                                        onError={(e) => {
                                                            const target = e.currentTarget;
                                                            const currentSrc = target.src;
                                                            const isDark = document.documentElement.classList.contains("dark");

                                                            if (currentSrc.endsWith('.jpg')) {
                                                                target.src = currentSrc.replace('.jpg', '.png');
                                                                return;
                                                            }
                                                            if (currentSrc.endsWith('.png') || !currentSrc.includes('placehold.co')) {
                                                                if (item.is_holiday) {
                                                                    const isSongkran = item.task_main?.includes('สงกรานต์') || false;
                                                                    const isChakri = item.task_main?.includes('จักรี') || false;
                                                                    const text = isSongkran ? "Songkran+Festival" : isChakri ? "Chakri+Memorial+Day" : "Weekend";
                                                                    target.src = `https://placehold.co/800x600/${isDark ? "1e1e20/666666" : "f3f4f6/aaaaaa"}?text=${text}`;
                                                                } else {
                                                                    target.src = `https://placehold.co/800x600/${isDark ? "1e1e20/ffffff" : "e2e8f0/000000"}?text=Week+${item.week_num}+-+Day+${item.id}`;
                                                                }
                                                            }
                                                        }}
                                                    />

                                                    {/* Badge วันหยุด */}
                                                    {item.is_holiday && (
                                                        <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px] flex items-center justify-center transition-all duration-300 z-10 pointer-events-none">
                                                            <span className="bg-white/95 text-black px-5 py-2 rounded-full font-bold text-xs shadow-xl tracking-wide flex items-center gap-2">
                                                                {item.task_main?.includes('สงกรานต์') ? '💦 วันหยุดสงกรานต์' : item.task_main?.includes('จักรี') ? '👑 วันจักรี' : '🌴 วันหยุด'}
                                                            </span>
                                                        </div>
                                                    )}

                                                    {/* Hover Overlay */}
                                                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-5 z-20">
                                                        <div className="translate-y-0 sm:translate-y-4 sm:group-hover:translate-y-0 transition-transform duration-300">
                                                            <p className="text-white font-bold text-sm line-clamp-2 leading-tight">
                                                                {item.task_main || 'ไม่มีรายละเอียดงาน'}
                                                            </p>
                                                            <div className="flex items-center gap-2 mt-2">
                                                                <span className="text-white/80 text-[11px] font-bold flex items-center gap-1">
                                                                    <Calendar size={12} strokeWidth={2.5} /> {item.date_str}
                                                                </span>
                                                            </div>
                                                        </div>

                                                        {!item.is_holiday && (
                                                            <button className="absolute top-4 right-4 p-2.5 bg-white/10 hover:bg-red-500 text-white rounded-[1rem] backdrop-blur-md transition-colors shadow-sm">
                                                                <Trash2 size={16} strokeWidth={2.5} />
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}

                                            {/* Empty State */}
                                            {groupedImages[selectedWeek].length === 0 && (
                                                <div className="col-span-full py-20 flex flex-col items-center justify-center text-gray-400">
                                                    <Images size={48} className="opacity-20 mb-4" />
                                                    <p className="font-bold">ยังไม่มีรูปภาพในอัลบั้มนี้</p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                    {/* ลบส่วนปุ่ม Pagination ด้านล่างออกทั้งหมดแล้วครับ */}
                                </motion.div>
                            </div>
                        )}
                    </AnimatePresence>
                </>
            )}
        </div>
    );
}