"use client";

import React, { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { motion } from "framer-motion";
import { Plus, Edit3, Trash2, FileText, Loader2, Search, Calendar, ChevronRight } from "lucide-react";

export default function AdminReports() {
    const [reports, setReports] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");

    useEffect(() => {
        fetchReports();
    }, []);

    const fetchReports = async () => {
        setIsLoading(true);
        const { data } = await supabase
            .from('weekly_reports')
            .select('*, daily_tasks(count)')
            .order('week_num', { ascending: true });
        if (data) setReports(data);
        setIsLoading(false);
    };

    const filteredReports = reports.filter(r =>
        r.date_range.includes(searchTerm) || r.status?.includes(searchTerm)
    );

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 10 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } }
    };

    return (
        <div className="w-full relative min-h-screen">
            <div className="absolute top-20 right-1/4 w-[400px] h-[400px] bg-blue-500/5 rounded-full blur-[100px] -z-10 pointer-events-none" />

            <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-6 px-2">
                <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
                    <h1 className="text-3xl md:text-4xl font-black bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-500 dark:from-white dark:to-gray-500 tracking-tight mb-2 flex items-center gap-3">
                        จัดการรายงาน
                    </h1>
                    <p className="text-gray-500 text-sm font-bold">บันทึกและแก้ไขรายงานประจำสัปดาห์</p>
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col sm:flex-row gap-3">
                    <div className="relative group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 transition-colors group-focus-within:text-blue-500" size={18} strokeWidth={2.5} />
                        <input
                            type="text" placeholder="ค้นหาวันที่, สถานะ..."
                            value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full sm:w-64 pl-11 pr-4 py-3.5 bg-white/50 dark:bg-[#111113]/50 backdrop-blur-xl border border-gray-200/50 dark:border-white/10 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all dark:text-white"
                        />
                    </div>
                    <button className="bg-black dark:bg-white text-white dark:text-black px-6 py-3.5 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors shadow-sm group w-full sm:w-auto">
                        <Plus size={18} strokeWidth={2.5} className="transition-transform group-hover:rotate-90 duration-300" />
                        เพิ่มรายงาน
                    </button>
                </motion.div>
            </div>

            {isLoading ? (
                <div className="flex justify-center items-center py-32"><Loader2 className="animate-spin text-gray-300" size={32} /></div>
            ) : (
                <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-3 px-2">
                    {filteredReports.map((report) => (
                        <motion.div key={report.week_num} variants={itemVariants} className="p-4 md:p-5 rounded-[2rem] bg-white dark:bg-[#111113] border border-gray-100 dark:border-white/5 shadow-sm hover:shadow-md transition-all group flex flex-col md:flex-row md:items-center justify-between gap-4">

                            <div className="flex items-center gap-5">
                                <div className="w-16 h-16 rounded-[1.5rem] bg-gray-50 dark:bg-black flex flex-col items-center justify-center border border-gray-100 dark:border-white/5 shadow-inner transition-transform duration-300 group-hover:scale-105 group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 text-blue-500">
                                    <span className="text-[10px] font-black uppercase tracking-wider text-gray-400 group-hover:text-blue-400">Week</span>
                                    <span className="text-xl font-black leading-none text-gray-900 dark:text-white group-hover:text-blue-500">{report.week_num}</span>
                                </div>
                                <div>
                                    <h3 className="font-black text-gray-900 dark:text-white text-lg flex items-center gap-2">
                                        {report.date_range}
                                    </h3>
                                    <div className="flex items-center gap-3 mt-1.5">
                                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest ${report.status?.includes('ครบ') ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400'
                                            }`}>
                                            {report.status || "รอระบุสถานะ"}
                                        </span>
                                        <span className="text-xs font-bold text-gray-400 flex items-center gap-1">
                                            <FileText size={12} strokeWidth={2.5} /> {report.daily_tasks[0]?.count || 0} งาน
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="flex items-center justify-end gap-2 md:opacity-0 md:group-hover:opacity-100 transition-all duration-300 md:-translate-x-4 md:group-hover:translate-x-0">
                                <button className="p-3 bg-gray-50 dark:bg-white/5 hover:bg-blue-50 hover:text-blue-500 dark:hover:bg-blue-500/10 dark:hover:text-blue-400 text-gray-400 rounded-xl transition-colors">
                                    <Edit3 size={18} strokeWidth={2.5} />
                                </button>
                                <button className="p-3 bg-gray-50 dark:bg-white/5 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-500/10 dark:hover:text-red-400 text-gray-400 rounded-xl transition-colors">
                                    <Trash2 size={18} strokeWidth={2.5} />
                                </button>
                            </div>

                        </motion.div>
                    ))}
                    {filteredReports.length === 0 && (
                        <div className="text-center py-20 text-gray-400 font-bold">ไม่พบข้อมูลรายงานที่ค้นหา</div>
                    )}
                </motion.div>
            )}
        </div>
    );
}